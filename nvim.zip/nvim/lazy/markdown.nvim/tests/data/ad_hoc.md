# Heading

Heading 2 Line 1
Heading 2 Line 2
---

- [Normal Shortcut]
- [[Basic One]] Then normal text
- [[Nickname|With Alias]] Something important
- <test@example.com> Email
- [Youtube Link](https://www.youtube.com/watch?v=dQw4w9WgXcQ)
