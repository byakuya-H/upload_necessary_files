local a = 10
for i=1,10 do
  print(i)
  print(a)
end
