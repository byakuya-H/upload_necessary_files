select
    a,
    b
from tab;
