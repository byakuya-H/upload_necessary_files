def a():
    return

def a():
    return True

def a():
    return (1, 2, 3)

def a():
    return x.y.z

def a():
    return (
        1, 2, 3
    )

def a():
    return b(
        1, 2, 3
    )

def a():
    return [1, 2, 3]

def a():
    return {1, 2, 3}

def a():
    return {
        "a": 1,
        "b": 2,
        "c": 3
    }

def a():
    return [
        a for a in range (1, 3)
    ]
